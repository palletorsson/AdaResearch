#!/usr/bin/env python3
"""Static validation of this proposed editorial handover package only. No Godot or repo modifications."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
required=['README.md','BLOG_Writing_at_the_Edge_of_the_Simulation.md','HANDOVER_Final_Knowledge_Critique_and_Composition.md','EXAMPLE_Random_Definition_knowledge_and_routes.json','GHOST_READER_PROTOCOL.md','PROPOSED_TASKS_final_critical_composition.json','ASTRA_HANDOFF_FIRST_MESSAGE.md']
checks=[]
def check(label,result):
    checks.append((label,bool(result)))
    if not result: print('FAIL',label)
for f in required:check('exists:'+f,(ROOT/f).is_file() and (ROOT/f).stat().st_size>100)
example=json.loads((ROOT/'EXAMPLE_Random_Definition_knowledge_and_routes.json').read_text(encoding='utf-8'))
goal=json.loads((ROOT/'PROPOSED_TASKS_final_critical_composition.json').read_text(encoding='utf-8'))
pool=example['knowledge_pool'];ids=[x['id'] for x in pool]
check('9 unique knowledge connections',len(ids)==9 and len(ids)==len(set(ids)))
check('source revisions present',all(x.get('evidence_refs') and all(e.get('source') for e in x['evidence_refs']) for x in pool))
check('two distinct route IDs',len(example['route_trials'])==2 and len({r['id'] for r in example['route_trials']})==2)
for route in example['route_trials']:
    used=[c for card in route['paragraph_cards'] for c in card['connection_ids']]
    check('same full pool in '+route['id'],set(used)==set(ids) and set(route['selected_ids'])==set(ids))
    check('paragraph order and fields '+route['id'],all(c['position']==i for i,c in enumerate(route['paragraph_cards'],1)) and all(all(key in c for key in ['information','job','attitude','reader_gain','critical_pressure','experimental_potential','bridge','size']) for c in route['paragraph_cards']))
    check('450-700 word allowance '+route['id'],route['word_allowance']=={'min':450,'max':700})
check('no fabricated ghost or experiment results',all(r['ghost_review'] is None and r['human_decision'] is None for r in example['route_trials']) and example['review_result'] is None)
tasks=goal['tasks'];taskids=[t['id'] for t in tasks]
check('8 distinct tasks',len(tasks)==8 and len(set(taskids))==8)
check('all tasks open',all(t['status']=='open' and t['claimed_by'] is None and t['done_at'] is None for t in tasks))
check('dependencies resolve',all(dep in taskids for t in tasks for dep in t['depends_on']))
check('required task fields',all(all(k in t for k in ('id','title','spec','effort','skill','depends_on','status','claimed_by','done_at','artifact_refs','map_refs','output','verification')) for t in tasks))
for f in ['BLOG_Writing_at_the_Edge_of_the_Simulation.md','HANDOVER_Final_Knowledge_Critique_and_Composition.md']:
    text=(ROOT/f).read_text(encoding='utf-8').lower()
    check('critical lenses in '+f,all(w in text for w in ('edge','leak','technical bias','attachment')))
check('no repo mutation claimed', 'not** applied to the repository' in (ROOT/'HANDOVER_Final_Knowledge_Critique_and_Composition.md').read_text(encoding='utf-8'))
report={'status':'static_package_validation_only','checks':[{'check':k,'pass':v} for k,v in checks],'passed':sum(v for _,v in checks),'total':len(checks),'godot_runtime':'not_run','headset':'not_tested','human_readers':'not_tested'}
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
print(report['passed'],'/',report['total'],'static checks passed')
raise SystemExit(0 if report['passed']==report['total'] else 1)
