# Message to Astra — Final Knowledge and Critical Composition

**Target:** `palletorsson/AdaResearch`, branch `palm-scanner-door-entry`, baseline audited at `0870d9b04ff048df916c0a47312e67347237d502`. Check current local HEAD and uncommitted changes before starting.

The new work concerns **`final.md` knowledge selection and critical composition**, not a new random-number generator, book renderer or Godot hall. Read these companion files in order:

1. `HANDOVER_Final_Knowledge_Critique_and_Composition.md` — complete conceptual/editorial and implementation contract.
2. `EXAMPLE_Random_Definition_knowledge_and_routes.json` — nine candidate knowledge connections and two A/B paragraph timelines. These are **illustrative drafts**, with run/visitor claims not yet tested.
3. `GHOST_READER_PROTOCOL.md` — sequential reader-simulation method, distinct from the tutorial's ghost student.
4. `PROPOSED_TASKS_final_critical_composition.json` — repository-task-schema-compatible proposal. **Not registered; compare with existing `randomness_research_writing` W001–W005 before adding any tasks.**
5. `BLOG_Writing_at_the_Edge_of_the_Simulation.md` — public explanation of the artistic method, not an implementation specification.

**First action:** perform a **read-only reconciliation**. Verify `doc/book/RECURSIVE_ARCHITECTURE.md`, `doc/book/REVIEW_PRINCIPLES.md`, `doc/book/VOICE_STUDY.md`, `doc/book/course/randomness-research-2026-10-14/TEXT_SIMULATION.md`, the current Random Definition `final.md`/`tutorial.md`/`map_data.json`, `doc/book/experiments/README.md`, `doc/book/experiments/random-definition/seed-bench-001/experiment.json` and `doc/tasks/_schema.md`. Inspect the actually installed writing-pattern / research pool UI and data store in the encyclopedia/Ada Writer; do not invent or duplicate it from memory of the 13 October blog.

Return one focused proposal identifying what exists, what is missing, which data should be reused, how to represent nine typed knowledge connections, and whether W001–W005 already cover any proposed task. Do not modify canonical `final.md`, the active curriculum, book editions, experiment status, or task statuses at this stage.

Once reconciled, build a **staging-only Random Definition knowledge pool and two route timelines** (same selected claims, different motivations and bridges). Apply the original six paragraph fields plus optional critical pressure and experimental potential. Test a sequential ghost reader; source-check each technical claim; leave missing runtime and human evidence explicitly pending. Only after a human editorial choice should a selected proposition bind to the existing `seed-bench-001` text-simulation/Godot cycle. Do not invent an implementation result or jump automatically to the sleeve.

**Success condition:** someone can trace a line of `final.md` from a situated technical/scientific/geometric encounter, through a justified critical edge/leak/bias/attachment and editorial reason for appearing at that precise moment, into a revisable experimental proposition. The same person can retrieve unused alternatives, evidence status, ghost-reading limits, editorial selection and predecessor versions.
