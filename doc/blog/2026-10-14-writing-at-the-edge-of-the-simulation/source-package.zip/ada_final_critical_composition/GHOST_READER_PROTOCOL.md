# Ghost Reader Protocol for `final.md`

**Proposed editorial test · 14 October 2026 · Not evidence of human reception**

This is **not** the existing ghost student's code-reconstruction test. It is a sequential reading experiment for the critical and associative work of `final.md`. The model simulates a plausible first reading, identifies explanatory gaps and prematurely resolved questions, and makes its limitations explicit. It does not certify originality, pleasure, discomfort or bodily attachment.

## Inputs

- Source hall/sequence name and pinned text revision, plus previous/next hall connections.
- Intended reader profile: what mechanisms, terms and prior encounters are assumed; mark unknowns rather than granting hidden expertise.
- Candidate A or B reading route and its admitted research-pool IDs.
- Paragraph cards used by the editor, but **do not show the cards to the ghost reader before the blind read**.
- Text paragraphs delivered one at a time; withhold all later content.
- If an experiment's behaviour matters, provide its evidence status separately: inspected source, runtime capture, hypothetical text simulation, or human account.

## Blind per-paragraph sequence

1. Show the opening paragraph and nothing that follows. Ask what is concretely happening, what the reader can currently infer, and what they want to know next.
2. Reveal exactly the next paragraph. Ask what it answered, changed, or made stranger; whether it introduced new knowledge the reader had a reason to want; and whether a claim needs verification.
3. Continue without revealing later passages. Do not let a model reconstruct the rest of the text from a cached full source.
4. After the end, return to the opening and identify which later paragraphs transformed its meaning.
5. Compare two routes on *specific reasons* and their shared pool, without converting literary value into a number.
6. Show the editor's paragraph cards only after the blind report; compare intended job, reader's perceived job and evidence demands.

## A per-paragraph record

```json
{
  "route_id": "Random_Definition.route_A",
  "paragraph_index": 1,
  "visible_text_revision": "recorded_hash",
  "object_or_event_now_imaginable": "The right-hand grid differs while the seed stays.",
  "mechanism_understood": "No explanation yet of a discarded draw.",
  "active_question": "Why is the result different under the same number?",
  "anticipation": "An account of what that number controls.",
  "relation_to_previous": "Opening: no previous paragraph.",
  "transition_assessment": "Not applicable yet.",
  "critical_pressure_noticed": ["technical_bias_possible"],
  "claim_checks_requested": [],
  "attention_or_desire_hypothesis": "The visible mismatch gives a reason to continue.",
  "limits": "Model-generated reader simulation, not an observed human response."
}
```

The record fields for attraction or attention are **hypotheses**. They may fail entirely when confronted with human readers. Report a surprise or preference as *model-proposed* unless the human visitor actually reports it.

## Post-reading questions

- Which paragraph generated the clearest unanswered question, and did the next one do anything with it?
- Where did a technical explanation arrive too early? Where did it arrive too late to sustain trust?
- Which return genuinely changed an earlier encounter?
- Which historical or philosophical connection had a reason to enter, and which felt like a name-drop?
- Where did a critical association outrun the game's demonstrated geometry or behaviour?
- Where was a vivid proposal misreported as currently installed?
- Which paragraph can be removed without a meaningful change? Which cannot be removed without losing a discovery?
- Did the piece leave the next hall with a live question rather than a prefabricated conclusion?
- What might a human reader disagree with in this simulated reading?

## Evidence categories

| Finding | What can be claimed |
| --- | --- |
| Source inspection | A particular documented script, passage or value says X at the inspected revision. |
| Technical run | The observed operation did X under recorded build/input conditions. |
| Ghost reader | An AI-generated reading found a transition possibly confusing or productive. |
| Human reader | A person under reported circumstances actually gave that interpretation or experience. |
| Editorial decision | A responsible editor selected, revised, deferred or left the passage open for a stated reason. |

These findings cannot substitute for one another.

## Controlled A/B comparison

Admit the same knowledge pool items to both routes. Keep rough length and audience assumptions comparable, but **allow bridges and sentences to be rewritten**: the research question is whether a different *composition* changes the reader's unfolding inquiry, not whether identical paragraphs work in another order. Run each route in isolation if possible, so the model's recall of A does not contaminate B; disclose contamination and version if that is not possible.

Never declare the more coherent route automatically superior. A difficult leap may be the artistic moment that makes the piece memorable. The review is successful if it identifies **where knowledge entered, why the reader wanted or resisted it, and what changed afterward**.

## Integration contract

Store route-specific reports under a new proposed `doc/book/critical-composition/reviews/` location, separate from canonical hall prose. Reference exact source hashes and paragraph IDs. Link any chosen proposition to the existing `doc/book/experiments/` system. Preserve both reader reports, human decision, rejected or deferred possibilities and source revisions. Ghost-reader results must never auto-merge into `final.md` or a frozen edition.

## Agent-ready task prompt

> Read the supplied Ada Research `final.md` paragraphs sequentially. You are a provisional ghost reader, not a critic with access to the full manuscript. Use only the paragraphs already revealed and the declared prior knowledge. After each paragraph, report (1) the material encounter you imagine, (2) what technical mechanism you understand, (3) the question that currently motivates your reading, (4) whether this paragraph changes the significance of an earlier one, (5) any edge, omission, implementation bias or possible attachment, and (6) a claim or interaction that requires verification. Clearly distinguish actual textual evidence from assumptions and personal-response hypotheses. At the end, evaluate the sequence's transformations and remaining questions without an overall literary score. Never claim to have personally experienced the VR installation.
