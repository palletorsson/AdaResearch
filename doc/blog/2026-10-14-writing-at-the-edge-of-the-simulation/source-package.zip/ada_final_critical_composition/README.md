# Ada Research — The Critical-Composition Strategy

**Working package · 14 October 2026**  
**Reference:** `palletorsson/AdaResearch` / `palm-scanner-door-entry` / inspected commit `0870d9b04ff048df916c0a47312e67347237d502`  
**Status:** new draft blog and proposed editorial handover, **not** installed as a repository change. No Godot, physical VR or independent reader tests were carried out for this package.

## Files

| File | Purpose |
| --- | --- |
| `BLOG_Writing_at_the_Edge_of_the_Simulation.md` | Public-facing essay on critical attention, technical grounding, dissipated authorship and the text/game loop |
| `HANDOVER_Final_Knowledge_Critique_and_Composition.md` | Full specification for the missing `final.md` knowledge-selection and critical-composition layer |
| `EXAMPLE_Random_Definition_knowledge_and_routes.json` | Nine typed candidate knowledge connections and two eight-paragraph route cards; example, not canonical text |
| `GHOST_READER_PROTOCOL.md` | Test method for simulated sequential reading and editorial assessment |
| `PROPOSED_TASKS_final_critical_composition.json` | Eight proposal tasks following the existing goal/task schema; not registered |
| `ASTRA_HANDOFF_FIRST_MESSAGE.md` | Short, copyable instructions for local Astra; starts with read-only reconciliation |
| `validate_package.py` / `validation.json` | Static packaging checks only; not runtime or reader evidence |

## Principle

The **tutorial** teaches operational construction and tests it with a ghost student. The **final** cultivates a situated, associative, scientifically grounded **critical mindset** by looking for **edge, leak, technical bias and attachment**. A research pool preserves more knowledge than a chapter can use; paragraph cards compose a route in which each selected claim has a reason to enter. A ghost reader can identify weak transitions; human editorial attention decides what matters. Selected literary propositions may become text simulations and Godot experiments, whose observations may revise the two texts or the research plan.

This extends the existing reciprocal experiment architecture rather than creating a competing book index. Preserve source versions, alternate interpretations, incomplete tests, unused branches, failed experiments and learning debt.

## Usage

Read the blog for public argument and the handover for implementation. Start Astra with `ASTRA_HANDOFF_FIRST_MESSAGE.md`. Do not copy `PROPOSED_TASKS_...json` into `doc/tasks/` without checking existing W001–W005 for overlap and reviewing dependencies with the local source of truth. The JSON example's evidence status is provisional until checked against current source and runtime.
