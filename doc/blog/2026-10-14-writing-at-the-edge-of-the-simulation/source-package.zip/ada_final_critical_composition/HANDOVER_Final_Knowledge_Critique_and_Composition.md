# Ada Research — Full Handover: Knowledge, Critical Attention and Composition for `final.md`

**Date:** 14 October 2026  
**Status:** Editorial and technical strategy, implementation proposal, **not** applied to the repository  
**Repository:** `palletorsson/AdaResearch`  
**Branch audited:** `palm-scanner-door-entry`  
**Commit inspected:** `0870d9b04ff048df916c0a47312e67347237d502`  
**Audience:** Astra / local coding agent, book/editorial collaborators, AI-assisted research workers  
**Priority:** Add the missing critical-knowledge composition process for `final.md` without replacing the existing tutorial, museum, experiment, or task systems.

## Executive directive

**Preserve two distinct but reciprocal text practices.**

- `tutorial.md` establishes operational capacity: a learner can build, predict, compare, modify and reconstruct an explicitly supplied mechanism. Its technical ghost student and eventual independent learner test reveal missing prerequisites, errors and hidden dependencies.
- `final.md` establishes a situated, critical, associative encounter: it follows the material and mathematical operation, seeks its **edge, leak, technical bias and attachment**, brings in relevant historical/scientific/artistic knowledge, and composes a reader's growing desire to understand or intervene. Its ghost reader can test transitions and comprehension, but not certify literary pleasure or critical value.

**Do not treat `final.md` as explanation layered over code or as a prose copy of the tutorial.** The two texts may initiate experiments independently. Simulations and observations may revise either, both or neither, with reasons and versioned evidence.

The missing intermediary is **a knowledge–critical-attention–composition process**:

`current artifact / observation / source → research pool → critical lenses → knowledge-desire selection → paragraph cards → competing routes → final.md → ghost reader and human review → text simulation / Godot experiment → observation → revised pool, texts and possibly task graph`.

This method extends `doc/book/RECURSIVE_ARCHITECTURE.md`, not a new book renderer or second canonical index.

## 1. Existing sources of truth and their limits

### Confirmed in the inspected repository

| File or location | Present function | Respect during integration |
| --- | --- | --- |
| `doc/book/RECURSIVE_ARCHITECTURE.md` | Six connected components, two equal text practices, experiment companions, versions and editions | Extend with an upstream critical-composition stage; do not bypass its evidence distinctions |
| `doc/book/course/randomness-research-2026-10-14/TEXT_SIMULATION.md` | Reciprocal text/world loop, learning debt, task-graph revision and two opening-route trials | Reuse experiment proposition and observation contracts |
| `doc/book/experiments/README.md` | Stable experiment/passage/interpretation/run IDs, source snapshots, hypothesis vs execution, reviews | Link an accepted knowledge item to an experiment ID rather than duplicating a run |
| `doc/book/experiments/random-definition/seed-bench-001/` | Proposed 48-value RGB/height comparison; no executed run | Use as the first test of a passage leading to a controlled implementation |
| `doc/book/REVIEW_PRINCIPLES.md` | Strengthen encounter → staging → relationship → cut; preserve counterexamples and secondary artifacts | Never resolve a textual mismatch by reflexively cutting the passage |
| `doc/book/VOICE_STUDY.md` | Oscillation between anomaly, technical principle and further difference; no mandatory rhythm | Preserve sensuous strangeness and precise causal explanation |
| `doc/book/BOOK_FRAME.md` | Published reading order and prose frame | No silent resequencing or automatic publication |
| `doc/book/course/COURSE_WORLD.md` | Existing Endless Museum is the learner environment | No duplicate museum or forced standalone tutorial universe |
| `commons/maps/<Map>/final.md` | Canonical hall-level reflective writing | Do not overwrite until a reviewed revision is selected |
| `commons/maps/<Map>/tutorial.md` | Canonical hall-level reconstructable lesson | Keep tutorial review independent of final review |
| `commons/maps/<Map>/map_data.json` and artifact scripts | Authored spatial/operational source | Verify claims against actual revision and, as needed, runtime |
| `doc/tasks/_schema.md` and existing `doc/tasks/randomness_research*.json` | Task goals, dependencies, status, review and verification | Reconcile/augment, never regenerate completed or claimed work blindly |

### Recovered 13 October writing model (user-provided working account)

The earlier writing desk described a **research pool**, a graph-to-line problem, paragraph cards, A/B route trials, bounded readings of philosophical/rhetorical movement, and a ghost student. Its six original paragraph fields were **Information / Job / Attitude / Reader's gain / Bridge / Size**. Its Random Definition comparison used the same selected knowledge connections in two differently written routes, not rearranged identical paragraphs. A/B evaluation favoured the first route's consequence-led opening with the second route's historical braiding.

The account also distinguished **installed behaviour, historical evidence, editorial interpretation and unbuilt proposal**; a missing source was not to be glossed into a fluent transition. Do not infer that every feature of the described local writing desk is already in the checked-out Git branch. **Inventory existing Ada Writer / encyclopedia components before implementing a new interface.**

## 2. The core epistemological distinction: good information vs good knowledge *here*

A technical fact can be true, relevant to an artifact and still unnecessary in this paragraph. A historical reference can be accurate and arrive before the reader has a reason to want it. A theoretical association can be interesting but too detached from the operational object to make a defensible critical claim.

The admission test for the `final.md` pool is not only “is it correct?” but **“why does this knowledge belong at this exact moment, and what does it change for the reader?”**

Evaluate potential connections across four independent dimensions:

1. **Situated and supportable:** traceable to a source, observed operation, defined formula, identifiable geometry or explicitly labelled speculation.
2. **Desired:** follows an anomaly, attachment or unresolved question that gives the reader a reason to pursue it.
3. **Transformative:** changes a prior description, question, assumption, perceived relation or sense of the object's limits.
4. **Generative:** can lead to another observation, experiment, bodily action, reconstruction, historical comparison or question.

These are editorial tests, **not weights in a mandatory score**. A historically necessary paragraph may primarily supply context; a precise definition may simply let the reader make an otherwise impossible distinction. Some moments deserve to linger without proving their usefulness in the next line.

Keep a reserve of knowledge that is valuable but poorly placed. Do not force it into the draft or discard it permanently.

## 3. The four critical lenses: concrete operational meanings

### EDGE — the boundary of an operation

Question: *Where does this apparatus stop, clip, exclude, fail, threshold or refuse?*

Typical investigations: fixed cells, truncated precision, controller reach, permitted coordinate plane, selection eligibility, finite state, unwalkable slope, numeric tolerance, simulation boundary, runtime performance.

Required anchor: a particular rule, limit, parameter, scene behaviour or demonstrable counterexample. The limitation can be useful or protective, not inherently oppressive.

**Random Definition:** RGB values change; cell count and positions remain fixed. The edge is specific to this implementation, not proof that randomness lacks novelty.

### LEAK — what a record or representation does not keep

Question: *What goes missing between event, measurement, simulation, display, archive and interpretation?*

Typical investigations: a histogram omits adjacency; a seed alone omits draw order; a screenshot omits haptic timing; a trajectory sample omits continuous movement; a displayed line need not be a collider; a textual hypothesis does not establish a running result.

Required anchor: specify **which input**, **which transformation**, **which output**, and **which omitted property**. Do not call an information loss a mathematical error if the measured quantity was intentionally narrower.

**Random Entropy:** sorting preserves symbol counts and first-order Shannon entropy while changing neighbours. Preserve the variable, alphabet and formula when making this claim.

### TECHNICAL BIAS — the decisions that shape possible outcomes

Question: *Which choices of sampling, units, coordinates, distribution, threshold, renderer, classifier, controller or default favor one representation or action over another?*

Required anchor: the actual chosen mapping and a plausible alternative or tested intervention. **Distinguish technical/design bias from evidence of social or political bias.** Moving from one to the other requires an argued relation and, where claimed, affected users or evidence.

**Random Definition:** three successive draws are assigned to R/G/B. An alternative mapping can assign them to height. Both are decisions about what the result controls; the RNG itself does not prescribe either.

### ATTACHMENT — the reason an encounter matters to someone

Question: *What does a visitor want to preserve, wear, follow, enter, escape, repeat or refuse?*

Typical investigations: colour relations preferred over successful replay; a difficult route chosen over a smooth one; a sculpture that invites physical identification; a surprising glitch someone wants to keep.

Required anchor: either a design invitation (as a possibility), an identifiable artistic interpretation, or a reported human encounter. **Do not invent visitor feelings or declare AI-generated affective assessments to be observations.**

**Random Definition:** the prompt to keep a patch is an invitation. A visitor actually reporting attachment would require recorded evidence. The sleeve is a possible future use, not an installed effect.

### Relationship among the lenses

An attachment may identify an edge; the edge may expose a bias; the bias can suggest a new receiver; the new receiver may leak information the old one preserved. These movements should be traced in their actual order. **Do not demand a complete four-lens inventory in every chapter.** Some chapters will work through one lens; others will be driven by an anomaly outside this vocabulary.

## 4. Scientific, mathematical and artistic boundaries

For every critical claim, record at least its epistemic type:

- **SOURCE** — exact checked code, map, manuscript passage, measurement definition or documented historical claim. Source existence does not prove VR behaviour.
- **RUNTIME TEST** — actual executed test with build, steps, input state, results and limits.
- **CAPTURE** — screenshot/video and method, including what it cannot show.
- **HUMAN ENCOUNTER** — attributed/consented account of a person's interaction under described conditions.
- **INTERPRETATION** — a motivated critical or aesthetic reading that may coexist with alternatives.
- **HYPOTHESIS / TEXT SIMULATION** — conditional possible behaviour; not observed.
- **PROPOSAL** — a scene, interaction or text not yet implemented.

Do not merge probability with entropy, source unpredictability with visual irregularity, chaos with new random forcing, a displayed boundary with physical collision, or aesthetic pleasure with a measured variable. When discussing QFEP, preserve it as the project's proposed theoretical/artistic framework and distinguish Shannon entropy from variational free energy and physical thermodynamic entropy.

A useful critical association has two linked records: **the technically supported anchor** and **the interpretive move**. Either may be revised independently. An encounter can refute a proposed interpretation without invalidating the underlying formula.

## 5. Research pool schema and decision process

Start with a lightweight JSON pool per hall, referencing existing assets and experiment records. The example package includes `EXAMPLE_Random_Definition_knowledge_and_routes.json`.

Suggested item fields:

| Field | Purpose |
| --- | --- |
| `id`, `hall`, `anchor_artifact` | Stable identity and exact place of encounter |
| `claim` | One concrete, bounded proposition; avoid bundles of assertions |
| `knowledge_kind` | `operational`, `historical`, `mathematical`, `critical`, `artistic`, `speculative` |
| `epistemic_status` | `source_checked`, `runtime_checked`, `historically_sourced`, `interpretation`, `hypothesis`, `proposal`, `needs_research` |
| `evidence_refs` | Paths/URLs plus revision or snapshot; no invented runtime evidence |
| `critical_lenses` | Zero or more of `edge`, `leak`, `technical_bias`, `attachment`, each with a stated referent |
| `why_here` | The reader's currently live question or attachment |
| `transformative_relation` | Which earlier understanding this changes, if any |
| `experimental_affordance` | A bounded intervention or next observation; may be `null` |
| `links` | Related connection IDs, adjacency alternatives, history/theory associations |
| `disposition` | `selected`, `reserve`, `needs_research`, `deferred`, `rejected` with reason |

**Selection loop:** collect without flattening → verify basic grounding → write possible critical interpretations separately from verified mechanisms → identify the reader's current desire/question → shortlist only what changes that inquiry → preserve the unused pool → compose a reading route.

If an artifact sparks a compelling passage that exceeds the current installation, examine recovery or an artifact-development task before cutting it. This extends the repository's existing review hierarchy.

## 6. The paragraph card — eight functional questions

The 13 October method's six fields remain canonical. Add two as optional explicit prompts, not mandatory prose categories.

| Card | Writer's question | Example (Random Definition) |
| --- | --- | --- |
| **Information** | What precise knowledge enters? | The seed is unchanged; a draw is discarded before RGB assignment |
| **Job** | What must this paragraph do? | Undermine the expectation that a seed names an image |
| **Attitude** | From what stance does it speak? | Curious and exact, leaving room to prefer the changed picture |
| **Reader's gain** | What new distinction is available afterward? | Starting state is not the same as the complete procedure |
| **Critical pressure** | Which edge/leak/bias/attachment becomes newly visible? | The draw's meaning is supplied by RGB interpretation; the picture's geometry stays fixed |
| **Experimental potential** | Can the association become a test? | Keep 48 draws; map the triples to height instead of only colour |
| **Bridge** | Why does the next connection belong now? | The wish to return asks why random numbers became retrievable |
| **Size** | How much duration is justified? | Enough for a first-cube example; no restart of the Colour tutorial |

A paragraph need not have a critical pressure or a proposed build. Its `bridge` should be a particular reader's changed question or an intentional interruption, **not** generic “now some history.” The `size` is a provisional space allowance, not a formula for all halls. Record any source requirements and any previous encounter this paragraph transforms.

## 7. From a graph to a chapter: alternative reading routes

The research pool is a graph; the published passage is a time-based path. **Do not assume the best topological or semantic connection is the best narrative transition.**

Run a small A/B route trial with the **same selected knowledge connections** and comparable word allowance. The prose and bridges may be rewritten to fit each route: this tests competing editorial constructions, not identical paragraphs in different positions.

For Random Definition, compare:

- **Route A — consequence first.** Begin with +1 DRAW and the disagreement; uncover its procedure; visit RAND, the falling page, the sphere and the possibility of changed rules.
- **Route B — encounter/history braid.** Begin with the desire to recover a patch or with the sphere's bodily return; move between machine and historical promise before explaining the discarded draw.

Do not confuse this literary A/B with the existing **RGB versus RGB+height** implementation experiment. They need separate IDs, comparison methods and evidence.

For each route create a paragraph timeline, then test its transitions. Ask of every important return: **Does this new encounter make something earlier more interesting than it was before?** Keep productive friction, strange leaps and pauses where their consequences are felt. A perfectly smooth chain can become generic explanatory prose.

The 13 October consolidated preference was B's historical braiding with A's stronger visible-disagreement opening. That is a working editorial result, not proof that one fixed template should govern 200+ rooms.

## 8. Ghost reader, ghost student and human review — distinct jobs

### Technical ghost student (`tutorial.md`)

Input: previous checked learner project, current printed lesson, declared supplied infrastructure, exact expected output and test instructions.

Tasks: reconstruct from only the stated inheritance; flag missing references, code, methods, controls and prerequisites; predict one change; deliberately test one plausible failure; independently compare result with stated mechanism.

Output: construction trace, exact source/probe evidence, missing dependency and unresolved learner questions. **AI reconstruction is an automated teaching check, not evidence that an independent human learned.**

### Sequential ghost reader (`final.md`)

Input: one candidate draft, the active chapter context, a deliberately bounded previous-knowledge profile, and its paragraph timeline. Withhold later paragraphs.

For each paragraph: read only what is exposed so far. Report (a) what object or action is currently imaginable, (b) what mechanism is understood and what remains unknown, (c) what question/desire the paragraph creates, (d) what it changes about an earlier moment, (e) whether the next promised bridge feels motivated, forced or productively strange, and (f) any claim needing a source or behavior test.

After the final paragraph: report the strongest unanswered question, the point where desire or attention declined, the paragraph that prematurely told the reader the thesis, and any critical analogy that appears unearned. Compare the A/B routes using their reasons, not a numerical rating alone. An AI reader can flag coherence and plausible reader expectations; **it cannot certify lived pleasure, critical originality or real VR attachment**.

### Human artist/editor checkpoint

Review the material encounter, scientific grounding, literary rhythm, associative potential, source provenance and what remains worth investigating. Decide `retain`, `revise`, `develop_artifact`, `research_source`, `defer`, or `keep_open_question` with evidence/reason. Do not automatically select a route by ghost score. A negative or dull result is evidence worth retaining.

### Human visitor/learner later

Test reconstructability, intelligible encounter, actual reach/readability and whether observations or attachments occur. Record consent, order, prior knowledge, headset/build and limitations. Human findings may challenge both AI reading and author assumptions.

## 9. Integrate with text simulation and Godot, without confusing states

**Only selected passages should be converted to computational propositions**. A literary sentence is not a full specification, and a model's predicted outcome is not a Godot result.

For an admitted experiment:

1. Preserve the selected passage and its SHA/recoverable source version.
2. State the exact operational anchor and identify where literary interpretation begins.
3. Write one or several explicit interpretations, assumptions and exclusions.
4. Text-simulate possible states, including plausible failures. Mark as hypothetical.
5. Build one bounded Godot variant, preferably within the existing room; record scene/build identity.
6. Establish baseline → change one condition → observe → keep → replay → independently reconstruct → decide next change.
7. Review `tutorial.md` and `final.md` separately; either may be revised, retained with reason or left open.
8. Update the pool and, when evidence warrants it, the future task graph. Preserve the preceding version and decision.

The already specified `seed-bench-001` RGB/height experiment provides this first bounded implementation. **Do not invent a second independent persistence layer for the same values**, and do not replace its 4×4 reference with a new geometry without recording an explicit variant.

**Cross-hall transfer is a separate test level.** A record that reproduces inside one instrument does not prove portability into a different receiver. Headset comfort, spatial accessibility and human learning also require separate checks.

## 10. Worked editorial pilot: Random Definition

### Candidate pool (ordered provisionally, not all destined for prose)

1. `R01` Seed/draw mismatch: +1 DRAW changes RGB grouping under a stable seed. **SOURCE**: current `final.md`, tutorial, seed bench source; runtime scope must be checked against current build.
2. `R02` Desired colour neighbours: an invitation to keep a patch, **ATTACHMENT hypothesis**, not an observed visitor preference.
3. `R03` RAND 1955 table: historically produced fixed digits reusable by location. **HISTORICAL** source needed; verify details with RAND's production account before final publication.
4. `R04` Moving-number page: fixed table analogy frustrated by disappearing cells. **SOURCE** in `final.md`; verify actual timing and retention in its script/runtime if claims will be strengthened.
5. `R05` Returning sphere: bodily involvement, fixed return vs variable excursion. **HYPOTHESIS/SEPARATE ARTIFACT** until interaction is checked.
6. `R06` Shannon entropy omits adjacency because the specified meter counts symbol frequencies. **MATHEMATICAL + SOURCE**; compare equal histograms, altered order in `Random_Entropy`.
7. `R07` RGB as a choice of receiver: a draw has no native colour role. **OPERATIONAL/TECHNICAL BIAS**.
8. `R08` Height interpretation of same forty-eight draws. **PROPOSAL**, linked to `seed-bench-001`; not run.
9. `R09` A connected/wearable sleeve. **LITERARY PROPOSAL**; do not imply present force-bearing connections or cloth physics.

### Indicative eight-movement paragraph timeline

| Movement | Reader's question | Paragraph job | Pressure | Next bridge |
| --- | --- | --- | --- | --- |
| 1. Visible discrepancy | Why did one image change? | Open with consequence | Attachment + operational anomaly | Investigate the unchanged number |
| 2. Procedure | Why didn't the seed preserve the image? | Explain generator/request roles | Technical bias | The promise of returning |
| 3. History | Why did people want reusable chance? | Give RAND a reason to enter | Historical complication | Return depends on retrieval |
| 4. Falling page | Can I reopen the lost line? | Make a promise fail materially | Leak | Other kinds of return |
| 5. Sphere | What is the same after a journey? | Move from representation to body | Edge / attachment | Compare permitted actions |
| 6. Colour and geometry | Who decided what could change? | Expose variable vs fixed properties | Technical bias / edge | Ask what else could be done |
| 7. Imagined sleeve or height study | What would a changed receiver make possible? | Open a buildable proposition without claiming it exists | Speculation | Need for a new experiment |
| 8. Hand-off to entropy | What does the next gauge preserve? | Revisit the patch through a new measure | Leak | Visit the next hall |

This is a **draft planning experiment**. The current canonical `Random_Definition/final.md` includes a textile panel description while the more recent illustrated editorial review describes relocating those panels to 10 PRINT. Confirm **current map, source, local uncommitted work and runtime** before writing as if the relocation is installed. Similarly, note that `R06` belongs primarily to the next hall, and do not exhaust that encounter in the previous chapter.

### The pilot's decisive editorial result

The pilot must demonstrate *why* a piece of knowledge was selected and *what changed because it entered*. It does not pass merely because the prose mentions all four critical lenses, or because the ghost reader gives it a high score. At least one strong bridge, one grounded critical inference, one preserved open possibility, and one evidence-linked choice to revise/retain/defer should be inspectable.

## 11. Proposed file integration (minimal, no live changes now)

Do not create an independent encyclopedia or migrate all chapters. Suggested proposal, subject to reconciliation with existing writing-desk components:

```text
doc/book/
    RECURSIVE_ARCHITECTURE.md             # existing; add a link upstream
    FINAL_KNOWLEDGE_COMPOSITION.md        # proposed method document
    critical-composition/                 # proposed planning companions
        README.md
        pools/Random_Definition.json
        routes/Random_Definition.A.json
        routes/Random_Definition.B.json
        reviews/Random_Definition.md
        templates/knowledge-connection.json
        templates/paragraph-card.json
```

Keep raw pool and draft prose independently versioned. Link knowledge connections to the existing experiment IDs, not copied observation logs. Use Git SHA or recoverable snapshot bytes and hashes. Preserve route variants, source decisions and unused branches. No canonical `final.md` mutation until editorial review.

Before implementing UI, **inspect existing writing-pattern and paragraph-route features in the local encyclopedia and Ada Writer**, including their current data stores and editing capabilities. The recovered 13 October account describes an interface but its complete current Git-backed implementation was not verified in this audit. Reuse working infrastructure if present.

## 12. Implementation work packages — proposed, not registered

A compatible draft goal is supplied as `PROPOSED_TASKS_final_critical_composition.json`; reconcile it with the existing `randomness_research_writing` W001–W005 tasks before adding any new tracker entries.

**Work order:**

1. **Inventory and reconcile** the 13 October writing pool/paragraph tools, `final.md` sources, existing research experiments, editorial plans and task files. Record what is already functional vs proposed.
2. **Define the pool contract** and the four critical lenses with source-scoped examples and a JSON validator. Start with one hall, not a museum-wide migration.
3. **Implement paragraph cards and route variants** using the original six fields plus critical pressure/experimental potential. Retain unused connections and previous versions.
4. **Run Random Definition A/B writing pilot** on the same selected pool items, with source checked claims and comparable length; preserve both drafts, their paragraph routes and the reasons for the editorial choice.
5. **Run ghost reader + source audit** with paragraph-reveal protocol. Output typed findings and human editorial decisions; do not treat scores as proof.
6. **Link one selected final proposition** to existing `seed-bench-001`. Use its text-sim / Godot/reconstruction experiment contract; do not run a fabricated test or promise a sleeve.
7. **Perform reciprocal review** after actual evidence: reconsider tutorial and final independently, identify learning debt, then allow the task plan to continue, redirect, defer or stop.
8. **Document and edition-proof** the approach: recoverable sources, decisions, open material, no silent mutation of frozen reading editions.

### Verification contract

- **Static knowledge integrity:** stable IDs, existing path/anchor references, explicit evidence states, no phantom scene, valid pool-to-paragraph links, retained reserve items, reproducible candidate route IDs.
- **Technical grounding:** exact formula/source where an operational claim requires it; code inspection separated from running tests.
- **Composition integrity:** both A/B routes use the same admitted knowledge items; paragraph jobs and bridges are inspectable; no forced four-lens checklist.
- **Ghost reader test:** sequential withheld-paragraph trace and transparent reported limitations.
- **Experiment integrity:** source snapshots, interpretations, text hypothesis, actual run and human-learner evidence correctly distinguished; no automatic claim that `seed-bench-001` has run.
- **Editorial result:** explicit retain/revise/develop/defer judgment and why; contradictory accounts remain available.
- **Integration:** generated companion records link to `RECURSIVE_ARCHITECTURE.md` and task plan without overwriting canonical hall texts or creating a competing book index.
- **Runtime/VR:** only necessary for actual scene edits; never inferred from passing a JSON validator or an AI-generated screenshot description.

Existing useful commands once local paths are available:

```bash
python -X utf8 doc/book/experiments/validate_experiments.py
python -X utf8 doc/book/course/randomness-research-2026-10-14/validate_plan.py
python tools/map_pathfinder.py check Random_Definition --verbose

git diff --check
```

The pathfinder applies if map placement changes; the first two commands validate existing contract/plan structure, **not literary quality or an actual headset run**. The proposed pool/route validator would need to be written and tested as part of implementation, not invoked as though already available.

## 13. Decisions to preserve and decisions still open

**Already established by user direction / prior collaboration:** tutorial and final are distinct reciprocal practices; the recursive text/world loop; the seven-step experiment verification; ghost student for reconstruction; the knowledge pool and six-field paragraph card; the importance of critical edges, leaks, technical biases and attachments; scientific/geometric grounding; associative strangeness; and the right of future observations to change writing and task order.

**Proposed here (not yet implemented or author-accepted as exact format):** an explicit editorial knowledge/critical-composition stage, two optional card fields, a concrete pool schema, the ghost-reader reveal protocol, its storage paths and this exact eight-task packaging. These are starting specifications for review and local implementation, not discoveries already tested.

**Still open:** whether the recovered writing workbench stores data in a format reusable by the book pipeline; how to expose pool/route decisions in the encyclopedia UI; what additional lenses arise from other halls; whether the ghost-reader test finds useful problems; whether readers experience the proposed associations; whether the first implementation generates a genuinely interesting revision; and which future experiment observations justify.

## 14. Agent handoff — first actual action

**First action is a read-only reconciliation**, not a rewrite or a new hall. Open the inspected repository paths and compare them with local uncommitted work and the 13 October writing desk. Produce a single-page inventory: existing tools and storage, missing contracts, conflicting text/artifact placements, best place for companion files, and which proposed tasks would duplicate W001–W005.

Then create only the minimal Random Definition knowledge pool and A/B paragraph cards in staging. Run the ghost-reader and source-check pass and return the two texts and a short evidence report for editorial review. No one should edit `commons/maps/Random_Definition/final.md` before that choice. If the passage requires behaviour that is missing, open an explicitly proposed artifact task and preserve the passage rather than silently deleting its possibility.

**Completion standard:** a reader can trace a paragraph from an operationally grounded claim through its critical pressure, the reason it enters the chapter, its place in a tested reading route, and—where selected—into a text simulation and a Godot experiment that may change the paragraph again.

---

### Source links for the handoff

- [Book architecture](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/RECURSIVE_ARCHITECTURE.md)
- [Text Simulation Loop](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/course/randomness-research-2026-10-14/TEXT_SIMULATION.md)
- [Editorial review principles](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/REVIEW_PRINCIPLES.md)
- [Ada voice study](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/VOICE_STUDY.md)
- [Random Definition final](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/commons/maps/Random_Definition/final.md)
- [Random Definition tutorial](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/commons/maps/Random_Definition/tutorial.md)
- [Current seed experiment](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/experiments/random-definition/seed-bench-001/proposition.md)
- [Research implementation tasks](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/book/course/randomness-research-2026-10-14/TASKS.md)
- [Task schema](https://github.com/palletorsson/AdaResearch/blob/0870d9b04ff048df916c0a47312e67347237d502/doc/tasks/_schema.md)

*This handover is a proposed strategy and integration brief. No repository file, task status, scene or published edition was changed by its creation.*
